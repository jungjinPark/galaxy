#!/usr/bin/env node
// 하네스 쓰기·커밋 관문: Oracle 11g 비호환 문법과 하드코딩 시크릿을 차단한다.
//
// 1) PreToolUse (Write | Edit | MultiEdit): 편집 결과 파일 전체를 만들어 보고,
//    이번 쓰기로 새로 생긴 위반만 차단한다. 마커도 파일 전체에서 찾는다.
//    이미 있던 위반은 막지 않는다. 그 위반은 커밋 관문에서 걸린다.
// 2) PreToolUse (Bash): 명령이 git commit 이면 커밋될 파일 전체를 검사한다.
//    Bash 로 쓴 파일은 1) 을 거치지 않으므로 여기서 잡는다.
// 3) git pre-commit (.githooks/pre-commit): --staged 모드로 같은 검사를 한다.
//    사람이 직접 커밋해도 걸린다.
//
// 판정은 이 스크립트 안에서 한다. Claude 훅은 exit 2 로 차단하고, CLI 모드는 위반 시 exit 1 이다.
// 탐지는 정규식 기반이다. 모든 시크릿을 잡지는 못하므로 리뷰에서도 확인한다.
//
// 수동 점검: node .claude/hooks/guard-content.mjs --scan <경로> [<경로> ...]
//            node .claude/hooks/guard-content.mjs --staged
// 우회 1: 파일 안 "harness-guard: allow(oracle) <사유>" (Oracle 규칙만, 시크릿은 우회 없음)
// 우회 2: 환경변수 HARNESS_SKIP_GUARD=1 (Claude 훅만, 본인 세션에서만). --staged 모드에는 적용하지 않는다.

import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname, basename, isAbsolute } from 'node:path';
import { execFileSync } from 'node:child_process';

const ORACLE_EXT = new Set(['.xml', '.sql', '.java', '.kt']);
const CONFIG_EXT = new Set(['.properties', '.yml', '.yaml']);
const SCAN_SKIP = new Set([
  'node_modules', 'build', 'dist', 'target', 'out',
  '.git', '.gradle', '.dart_tool', '.idea', '.claude',
]);
const MAX_SCAN_BYTES = 2_000_000;

// Oracle 11g R2 에 없는 문법 (ADR-001)
const ORACLE_RULES = [
  { id: 'ORA-OFFSET', re: /\bOFFSET\s+[^;\n]{0,40}?\bROWS?\b/i,
    msg: 'OFFSET ... ROWS 는 12c+ 문법. 공통 페이징(PageRequest, ADR-003)을 쓴다' },
  { id: 'ORA-FETCH', re: /\bFETCH\s+(FIRST|NEXT)\b/i,
    msg: 'FETCH FIRST/NEXT 는 12c+ 문법. 공통 페이징(PageRequest, ADR-003)을 쓴다' },
  { id: 'ORA-LIMIT', re: /\bLIMIT\s+(\d+|#\{|\$\{)/i,
    msg: 'LIMIT 은 Oracle 에 없다. 공통 페이징(PageRequest, ADR-003)을 쓴다' },
  { id: 'ORA-IDENTITY', re: /\bGENERATED\s+(ALWAYS|BY\s+DEFAULT)\s+AS\s+IDENTITY\b/i,
    msg: 'IDENTITY 컬럼은 12c+. SEQUENCE 와 NEXTVAL 을 쓴다' },
  { id: 'ORA-APPLY', re: /\b(CROSS|OUTER)\s+APPLY\b/i,
    msg: 'APPLY 는 12c+ 문법' },
  { id: 'ORA-JSON', re: /\bJSON_(ARRAYAGG|OBJECT|VALUE|QUERY|TABLE)\s*\(/i,
    msg: 'JSON_* 함수는 11g 에 없다' },
  { id: 'ORA-IFEXISTS', re: /\bDROP\s+(TABLE|INDEX|VIEW|SEQUENCE)\s+IF\s+EXISTS\b/i,
    msg: 'DROP ... IF EXISTS 는 11g 에 없다. PL/SQL 블록으로 처리한다' },
  { id: 'ORA-TOP', re: /\bSELECT\s+TOP\s+\d/i,
    msg: 'SELECT TOP 은 SQL Server 문법' },
  { id: 'ORA-ILIKE', re: /\bILIKE\b/i,
    msg: 'ILIKE 는 PostgreSQL 문법. UPPER(...) LIKE UPPER(...) 를 쓴다' },
  { id: 'ORA-BOOLEAN', re: /\bBOOLEAN\b/i, only: ['.sql'],
    msg: 'SQL 컬럼 타입 BOOLEAN 은 Oracle 에 없다. NUMBER(1) 또는 CHAR(1) 을 쓴다' },
];

// 하드코딩 시크릿. 값 자체는 출력하지 않는다. 플레이스홀더(${...}, <...>, {{...}})는 통과한다.
const SECRET_RULES = [
  { id: 'SEC-AWS', re: /\bAKIA[0-9A-Z]{16}\b/,
    msg: 'AWS access key 형태 리터럴' },
  { id: 'SEC-PEM', re: /-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----/,
    msg: '개인키 블록' },
  { id: 'SEC-JWT', re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/,
    msg: 'JWT 형태 토큰 리터럴' },
  { id: 'SEC-FCM', re: /\bAAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{100,}/,
    msg: 'FCM 서버 키 형태 리터럴' },
  { id: 'SEC-JDBC-ACCOUNT', re: /jdbc:oracle:thin:[^\s/@'"]+\/(?!\$\{)[^\s@'"]+@/i,
    msg: 'JDBC 접속 문자열에 계정/비밀번호 리터럴' },
  { id: 'SEC-JDBC-PW', re: /jdbc:[^\s'"]*[?;&](password|pwd)=(?!\$\{)[^&\s'";]+/i,
    msg: 'JDBC URL 에 password 리터럴' },
  { id: 'SEC-BEARER', re: /\bBearer\s+(?!\$\{)[A-Za-z0-9._~+\/-]{20,}/,
    msg: 'Bearer 토큰 리터럴' },
  { id: 'SEC-ASSIGN',
    re: /(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|private[_-]?key|jwt[_.-]?secret)["']?[ \t]*[:=][ \t]*["']?(?![$<{*]|changeme|example|your[_-])(?=[A-Za-z0-9\/+_\-!@#$%^&*=]*[0-9!@#$%^&*=\/+])[A-Za-z0-9\/+_\-!@#$%^&*=]{8,}(?![A-Za-z0-9_(.])/i,
    msg: '시크릿 키-값 리터럴. 환경변수 ${...} 참조로 바꾼다' },
  { id: 'SEC-XML',
    re: /<(?:password|passwd|secret|api[_-]?key|jwt[_-]?secret)>\s*(?![$<{*])(?=[^<]*[0-9!@#$%^&*=\/+])[^<\s]{8,}\s*<\//i,
    msg: 'XML 설정의 시크릿 리터럴. 환경변수 ${...} 참조로 바꾼다' },
];

// 설정 파일 전용: 키 이름이 시크릿 단어로 끝나면, 값이 문자만으로 되어 있어도 리터럴이면 차단한다.
// 빈 값, ${...}, <...> 는 통과한다.
const CONFIG_SECRET_RULE = {
  id: 'SEC-CONFIG',
  re: /^[ \t]*[\w.-]*(?:password|passwd|pwd|secret|token|api[_-]?key|private[_-]?key|client[_-]?secret)[ \t]*[:=][ \t]*["']?(?![$<"'\s#]|$)[^\s#"']+/im,
  msg: '설정 파일의 시크릿 키에 리터럴 값. 환경변수 ${...} 참조로 바꾼다',
};

function isConfigFile(filePath) {
  const name = basename(filePath);
  return CONFIG_EXT.has(extname(name).toLowerCase()) || name === '.env' || name.startsWith('.env.');
}

// 위반을 { id, msg, line, match } 로 돌려준다.
function detect(filePath, text) {
  const ext = extname(filePath).toLowerCase();
  // 사유는 마커와 같은 줄에 있어야 한다 (줄바꿈을 넘어 사유를 읽지 않는다)
  const oracleAllowed = /harness-guard:[ \t]*allow\(oracle\)[ \t]+\S/.test(text);
  const rules = [];
  if (ORACLE_EXT.has(ext) && !oracleAllowed) {
    rules.push(...ORACLE_RULES.filter((r) => !r.only || r.only.includes(ext)));
  }
  rules.push(...SECRET_RULES);
  if (isConfigFile(filePath)) rules.push(CONFIG_SECRET_RULE);

  const found = [];
  for (const rule of rules) {
    const flags = rule.re.flags.includes('g') ? rule.re.flags : rule.re.flags + 'g';
    const re = new RegExp(rule.re.source, flags);
    let m;
    while ((m = re.exec(text)) !== null) {
      found.push({ id: rule.id, msg: rule.msg, line: text.slice(0, m.index).split('\n').length, match: m[0] });
      if (m[0].length === 0) re.lastIndex++;
    }
  }
  return found;
}

function fmt(v) {
  return '  L' + v.line + ' [' + v.id + '] ' + v.msg;
}

function findViolations(filePath, text) {
  return detect(filePath, text).map(fmt);
}

// after 에만 있는 위반을 돌려준다. 같은 규칙·같은 일치 문자열의 개수가 늘어난 만큼만 새 위반으로 본다.
function introduced(filePath, before, after) {
  const remaining = new Map();
  for (const v of detect(filePath, before)) {
    const key = v.id + '\u0000' + v.match;
    remaining.set(key, (remaining.get(key) || 0) + 1);
  }
  const added = [];
  for (const v of detect(filePath, after)) {
    const key = v.id + '\u0000' + v.match;
    const left = remaining.get(key) || 0;
    if (left > 0) remaining.set(key, left - 1);
    else added.push(v);
  }
  return added;
}

function hintFor(foundLines) {
  let hint = '';
  if (foundLines.some((line) => line.includes('[ORA-'))) {
    hint += '- Oracle 문법: 11g 호환 문법으로 고친다. 불가피하면 같은 줄에 사유를 붙여 "harness-guard: allow(oracle) <사유>" 한 줄을 남긴다.\n';
  }
  if (foundLines.some((line) => line.includes('[SEC-'))) {
    hint += '- 시크릿: 리터럴 대신 환경변수 참조 ${...} 로 바꾼다. 우회 경로는 없다.\n';
  }
  return hint;
}

// ---- 쓰기 관문 ----

function newTextOf(toolInput) {
  if (Array.isArray(toolInput.edits)) {
    return toolInput.edits.map((e) => e.new_string ?? '').join('\n');
  }
  if (typeof toolInput.content === 'string') return toolInput.content;
  return toolInput.new_string ?? '';
}

function readBefore(filePath, cwd) {
  if (!filePath) return '';
  const full = isAbsolute(filePath) ? filePath : join(cwd || process.cwd(), filePath);
  try {
    return readFileSync(full, 'utf8');
  } catch {
    return ''; // 새 파일
  }
}

function applyEdit(text, oldStr, newStr, replaceAll) {
  if (typeof oldStr !== 'string' || oldStr === '' || !text.includes(oldStr)) return null;
  // 함수 치환으로 넘겨 new_string 안의 $ 패턴이 해석되지 않게 한다
  return replaceAll ? text.split(oldStr).join(newStr) : text.replace(oldStr, () => newStr);
}

// 편집이 끝난 뒤의 파일 내용. 재현할 수 없으면 null.
function afterText(toolInput, before) {
  if (typeof toolInput.content === 'string') return toolInput.content;
  const edits = Array.isArray(toolInput.edits) ? toolInput.edits : [toolInput];
  let text = before;
  for (const e of edits) {
    const next = applyEdit(text, e.old_string, e.new_string ?? '', e.replace_all === true);
    if (next === null) return null;
    text = next;
  }
  return text;
}

function gateWrite(toolInput, cwd) {
  const filePath = toolInput.file_path ?? '';
  const before = readBefore(filePath, cwd);
  const after = afterText(toolInput, before);
  // 편집 결과를 재현할 수 없으면(대상 문자열 없음 등) 새로 쓰는 부분만 검사한다
  const found = after === null ? detect(filePath, newTextOf(toolInput)) : introduced(filePath, before, after);
  if (found.length === 0) process.exit(0);
  const lines = found.map(fmt);
  process.stderr.write('[guard-content] 쓰기 차단: ' + filePath + '\n' + lines.join('\n') + '\n' + hintFor(lines));
  process.exit(2);
}

// ---- 커밋 관문 ----

// "git commit", "git -C dir commit", "git -c key=value commit" 형태를 잡는다.
const GIT_COMMIT_RE = /(?:^|[\s;&|(])git(?:\s+-[Cc]\s+\S+|\s+--?[\w-]+(?:=\S+)?)*\s+commit\b/;

// "git commit -a", "-am", "--all" 이면 스테이징하지 않은 수정본도 커밋된다.
function commitIncludesWorkingTree(command) {
  const after = command.slice(command.search(/\bcommit\b/));
  return /\s(?:-[A-Za-z]*a[A-Za-z]*|--all)(?=\s|$)/.test(after);
}

function git(args, cwd) {
  return execFileSync('git', args, {
    cwd, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'],
  });
}

function nulList(out) {
  return out.split('\0').filter(Boolean);
}

// 커밋될 파일과 내용을 모은다. 스테이징 내용이 기준이고, -a 커밋이면 작업 트리의 수정본으로 덮는다.
function commitTargets(cwd, includeWorkingTree) {
  const root = git(['rev-parse', '--show-toplevel'], cwd).trim();
  const targets = new Map();
  for (const f of nulList(git(['diff', '--cached', '--name-only', '--diff-filter=ACMR', '-z'], root))) {
    targets.set(f, () => git(['show', ':' + f], root));
  }
  if (includeWorkingTree) {
    for (const f of nulList(git(['diff', '--name-only', '--diff-filter=ACMR', '-z'], root))) {
      targets.set(f, () => readFileSync(join(root, f), 'utf8'));
    }
  }
  return targets;
}

function checkCommit(cwd, includeWorkingTree) {
  const report = [];
  let checked = 0;
  for (const [path, read] of commitTargets(cwd, includeWorkingTree)) {
    const text = read();
    if (text.length > MAX_SCAN_BYTES || text.includes('\u0000')) continue; // 바이너리·대용량 건너뜀
    checked++;
    const found = findViolations(path, text);
    if (found.length > 0) report.push(path + '\n' + found.join('\n'));
  }
  return { checked, report };
}

function gateCommit(command, cwd) {
  if (!GIT_COMMIT_RE.test(command)) process.exit(0);
  let result;
  try {
    result = checkCommit(cwd || process.cwd(), commitIncludesWorkingTree(command));
  } catch (err) {
    // 커밋 대상을 확인하지 못하면 통과시키지 않는다 (실패는 드러나야 한다)
    process.stderr.write('[guard-content] 커밋 대상 파일을 확인하지 못해 커밋을 차단한다: ' + err.message + '\n');
    process.exit(2);
  }
  if (result.report.length === 0) process.exit(0);
  const all = result.report.join('\n');
  process.stderr.write('[guard-content] 커밋 차단: 커밋될 파일에 위반이 있다\n' + all + '\n' + hintFor(all.split('\n')));
  process.exit(2);
}

// ---- 진입점 ----

async function runHook() {
  if (process.env.HARNESS_SKIP_GUARD === '1') process.exit(0);

  let input;
  try {
    let raw = '';
    for await (const chunk of process.stdin) raw += chunk;
    input = JSON.parse(raw);
  } catch (err) {
    // 입력을 읽지 못했을 때 통과시키지 않는다 (실패는 드러나야 한다)
    process.stderr.write('[guard-content] 훅 입력을 읽지 못해 차단한다: ' + err.message + '\n');
    process.exit(2);
  }

  const toolInput = input.tool_input ?? {};
  if (input.tool_name === 'Bash') {
    gateCommit(toolInput.command ?? '', input.cwd);
    return;
  }
  gateWrite(toolInput, input.cwd);
}

function stagedCli() {
  let result;
  try {
    result = checkCommit(process.cwd(), false);
  } catch (err) {
    process.stderr.write('[guard-content] 스테이징 파일을 확인하지 못해 커밋을 차단한다: ' + err.message + '\n');
    process.exit(2);
  }
  if (result.report.length > 0) {
    const all = result.report.join('\n');
    process.stderr.write('[guard-content] 커밋 차단: 스테이징된 파일에 위반이 있다\n' + all + '\n' + hintFor(all.split('\n')));
    process.exit(1);
  }
  process.stdout.write('[guard-content] 스테이징 파일 ' + result.checked + '개 검사, 위반 0건\n');
  process.exit(0);
}

function collect(p, out) {
  const st = statSync(p);
  if (st.isDirectory()) {
    for (const name of readdirSync(p)) {
      if (!SCAN_SKIP.has(name)) collect(join(p, name), out);
    }
  } else if (st.size <= MAX_SCAN_BYTES) {
    out.push(p);
  }
}

function scan(targets) {
  if (targets.length === 0) {
    process.stderr.write('사용법: node .claude/hooks/guard-content.mjs --scan <경로> [...]\n');
    process.exit(2);
  }
  const files = [];
  for (const t of targets) collect(t, files);

  let total = 0;
  let checked = 0;
  for (const f of files) {
    const text = readFileSync(f, 'utf8');
    if (text.includes('\u0000')) continue; // 바이너리 건너뜀
    checked++;
    const found = findViolations(f, text);
    if (found.length > 0) {
      total += found.length;
      process.stdout.write(f + '\n' + found.join('\n') + '\n');
    }
  }
  process.stdout.write('검사 파일 ' + checked + '개, 위반 ' + total + '건\n');
  process.exit(total > 0 ? 1 : 0);
}

const mode = process.argv[2];
if (mode === '--scan') {
  scan(process.argv.slice(3));
} else if (mode === '--staged') {
  stagedCli();
} else {
  runHook();
}
