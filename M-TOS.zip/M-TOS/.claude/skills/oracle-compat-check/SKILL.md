---
name: oracle-compat-check
description: M-TOS 소스 전체(매퍼 XML, SQL, Java, Kotlin)를 Oracle 11g 비호환 문법과 하드코딩 시크릿에 대해 정적 검사한다. 매퍼를 바꾼 뒤, 머지 전, 또는 주기 점검 때 실행.
---

# /oracle-compat-check — Oracle 11g 호환 정적 검사

## 설명

쓰기 단계의 훅(`guard-content.mjs`)은 새로 쓰는 내용만 본다. 이 스킬은 이미 저장소에 있는 파일 전체를 같은 규칙으로 검사한다.
규칙의 정본은 ADR-001 이다. 규칙을 바꾸면 훅과 이 스킬이 같이 바뀌어야 한다.

## 에이전트

backend-reviewer (실행), harness-keeper (규칙 변경 시)

## 사용법

```bash
node .claude/hooks/guard-content.mjs --scan src
```

커밋 직전에 스테이징된 파일만 검사하려면 `--staged` 를 쓴다. git `pre-commit` 훅과 Claude 의 커밋 훅이 같은 판정을 쓴다.

```bash
node .claude/hooks/guard-content.mjs --staged
```

백엔드 경로가 정해진 뒤에는 실제 경로를 넘긴다. 예:

```bash
node .claude/hooks/guard-content.mjs --scan backend/src/main/resources backend/src/main/java
```

## 검사 범위

- 확장자: `.xml`, `.sql`, `.java`, `.kt` 에는 Oracle 규칙을 적용한다.
- 모든 텍스트 파일에 시크릿 규칙을 적용한다.
- 제외 디렉터리: `node_modules`, `build`, `dist`, `target`, `out`, `.git`, `.gradle`, `.dart_tool`, `.idea`, `.claude`
- 2MB 를 넘는 파일과 바이너리 파일은 건너뛴다.

## 결과 해석

| 종료 코드 | 의미 |
|---|---|
| 0 | 위반 없음 |
| 1 | 위반 있음 (파일·줄·규칙 ID 출력) |
| 2 | 사용법 오류 |

- 규칙 ID 는 `ORA-*`(Oracle 문법)와 `SEC-*`(시크릿)로 나뉜다.
- `SEC-*` 위반은 값을 출력하지 않는다. 해당 줄을 직접 열어 환경변수 참조로 바꾼다.
- `ORA-*` 위반에 `harness-guard: allow(oracle) <사유>` 가 있으면 검사에서 빠진다. 이 마커 목록을 따로 뽑아 사유가 타당한지 확인한다.

## 한계

- 정규식 기반이다. 문자열 연결로 만든 SQL 이나 주석 속 문법은 놓치거나 과잉 탐지할 수 있다.
- 실제 11g 에서 실행해야 확인되는 문제(예: 드라이버 호환, null 바인딩)는 잡지 못한다. 그건 ADR-002 의 스파이크에서 확인한다.

## 금지

- 위반을 무시하고 "통과"로 보고하기
- 마커를 사유 없이 추가하기
- 규칙을 완화하려고 검사 코드를 고치기 (규칙 변경은 ADR 을 먼저 갱신한다)
