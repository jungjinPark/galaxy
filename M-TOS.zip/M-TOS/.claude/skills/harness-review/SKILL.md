---
name: harness-review
description: M-TOS 하네스 변경(CLAUDE.md, .claude/agents, .claude/skills, .claude/hooks, .claude/philosophy.md, docs/adr)의 의미 충돌과 사실 정확성을 검토한다. 하네스 파일을 바꾼 뒤 확정하기 전 실행. 제품 코드 리뷰에는 쓰지 않는다.
---

# /harness-review — M-TOS 하네스 변경 검토

## 설명

하네스 변경을 두 축으로 검증한다. 둘 다 해야 검토가 끝난다.

| 축 | 묻는 것 | 빠뜨리면 |
|---|---|---|
| 의미 충돌 | 기존 규칙과 모순·중복되는가, 다른 에이전트의 책임을 침범하는가 | 규칙끼리 싸우는 하네스가 된다 |
| 사실 검증 | 문서가 주장하는 파일 경로·명령·값이 실제와 맞는가 | 틀린 것을 지시하는 하네스가 된다 |

## 에이전트

harness-keeper

## 실행 절차

### Step 1. 변경 수집

커밋 전 변경과 새 파일을 모두 본다. 기준 브랜치는 `main` 이다.

```bash
git status --short
git diff main --name-only -- CLAUDE.md .claude docs .githooks .gitignore
git ls-files -o --exclude-standard -- CLAUDE.md .claude docs .githooks
```

- 세 번째 명령에 나온 새 파일은 diff 가 없으므로 내용 전체를 읽는다.
- 이미 커밋된 변경을 검토할 때는 대상 커밋 범위를 사용자에게 받는다. 추측으로 범위를 정하지 않는다.

### Step 2. 쓰기 검사 (먼저 한다)

```bash
node .claude/hooks/guard-content.mjs --scan CLAUDE.md docs .claude .githooks
```

- 시크릿 리터럴이 있으면 BLOCKER 다. 값은 보고서에 옮기지 않는다.
- `harness-guard: allow(oracle)` 마커가 있으면 사유가 실제로 타당한지 확인한다. 사유가 없으면 무효다.

> `.claude` 디렉터리는 스캔 기본 제외 목록에 있다. 위처럼 경로를 명시해야 검사된다.

### Step 3. 규칙 인벤토리 구축

현재 기준(main 또는 변경 전)으로 아래를 모아 `위치 · 내용 · 적용 범위`로 정리한다.

| 소스 | 수집 대상 |
|---|---|
| `CLAUDE.md` | 기술 스택, Oracle 규칙, 보안, 하네스 운영, 모델 티어 |
| `.claude/agents/*.md` | 역할, 체크리스트, 금지사항, 도구, 모델·effort |
| `.claude/skills/*/SKILL.md` | 절차, 제약, 금지 |
| `.claude/hooks/*.mjs` | 차단 규칙 ID, 우회 경로 |
| `.claude/philosophy.md` | 5대 원칙 |
| `docs/adr/*.md` | ADR 원본과 상태(Accepted / Proposed) |
| `.claude/settings.json`, `.githooks/` | 훅 등록, 커밋 관문 |
| `docs/harness-guide.md`, `docs/harness-checklist.md` | 작업자 안내, 미확정 항목, 실 환경 확인 항목 |
| `docs/legacy/*.md` | 분석 결과 수용 절차, 기능 ID 형식 |

이 단계를 건너뛰면 충돌을 볼 수 없다.

### Step 4. 의미 충돌 탐지

| 유형 | 설명 | 심각도 |
|---|---|---|
| 모순 | 기존 규칙과 직접 충돌 | BLOCKER |
| 중복 | 이미 있는 규칙의 재정의 | WARNING |
| 범위 침범 | 다른 에이전트·스킬의 책임을 침범 | WARNING |
| 사상 불일치 | philosophy.md 원칙에 반함 | WARNING |
| 모델 정책 위반 | `haiku` 에 effort, `inherit` 에 effort, 역할과 맞지 않는 티어 | BLOCKER |
| 부작용 | 의도하지 않은 다른 규칙에의 영향 | NIT |

판단 기준:
- 규칙의 예외 조건과 적용 범위를 정확히 본다. 문맥이 다르면 모순이 아니다.
- ADR 이 있는 규칙은 ADR 원문과 대조한다.
- 훅 규칙을 추가·수정하면 차단 ID 와 우회 경로가 CLAUDE.md 와 맞는지 본다.

### Step 5. 사실 검증

문서가 하는 주장을 실행해서 확인한다. 추정으로 넘기지 않는다.

| 주장 유형 | 검증 |
|---|---|
| 파일·경로 이름 | Glob, Grep 으로 존재 확인 |
| 명령 | 그대로 실행한다. keeper 권한 밖 명령(`./gradlew`, `docker compose`, `npm`, `flutter`)은 실행하지 않고 "미실행, 사유: 권한" 으로 적은 뒤, 해당 영역 reviewer 나 사용자에게 실행을 요청한다 |
| 훅 차단 동작 | 샘플 입력을 넣어 exit 코드 확인 |
| ADR 상태 | 미검증 항목(ADR-002 등)이 "확정"으로 쓰이지 않았는지 확인 |
| 선례로 인용한 파일 | 그 파일이 규약을 지키는지 확인 |

### Step 6. 리포트

```markdown
## 하네스 검토 리포트
### 대상: {변경 범위}
### 판정: APPROVE / REQUEST_CHANGES / COMMENT

### 변경 요약
{파일별 한 줄}

### 쓰기 검사
{통과 / 위반 내역 (값은 제외)}

### 의미 충돌
| # | 파일 | 변경 | 유형 | 심각도 | 설명 |

### 사실 검증
| # | 주장 | 검증 방법 | 결과 |

### BLOCKER 상세
{기존 규칙 원문 · 제안 규칙 원문 · 충돌 지점 · 해소 제안}

### 권장 조치
- APPROVE: BLOCKER 0건
- REQUEST_CHANGES: BLOCKER 해소 필요
- COMMENT: WARNING 만 존재, 사용자 판단
```

### Step 7. 사용자 판단 대기

리포트를 보고하고 기다린다. 승인 없이 하네스 파일을 고치지 않는다.

## 금지

- 규칙 인벤토리 없이 검토하기
- 사실 검증 없이 APPROVE 하기
- 제품 코드 리뷰 (해당 영역의 reviewer 담당)
- BLOCKER 를 남긴 채 확정하기

## 보류 항목

- 원격 PR 흐름(GitLab MR 연동)은 서비스 결정 후 별도 스킬로 추가한다. 이 스킬은 로컬 변경을 검토한다.
