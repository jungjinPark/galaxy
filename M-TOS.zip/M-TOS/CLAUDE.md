# M-TOS 프로젝트 지침

## 프로젝트

고객사 요청에 따른 개발환경 구성. 현재 저장소에는 코드가 없고 설계 단계다.
설계 근거는 고객 요청 문서 기반 개발환경 설계(2026-10-18 정리)이며, 확인되지 않은 항목은 ADR에 미검증으로 표시한다.

## 기술 스택

| 영역 | 스택 |
|---|---|
| backend | JDK 21, Spring Boot 3.5, Spring Security 6.x, MyBatis 3.5, HikariCP, Gradle |
| DB | Oracle 11g R2 (로컬: `gvenzl/oracle-xe:11`) |
| 캐시·인증 | Redis 7.x, JWT Access/Refresh 이중 토큰 (Refresh 는 Redis 에서 rotation·폐기) |
| frontend | Vue 3 (Composition API), Vite, Pinia, Vue Router, Axios |
| mobile | Flutter (Dart 3.x), InAppWebView, JS Channel, FCM |
| infra | docker-compose, ALB 뒤 다중 WAS, Graceful Shutdown |
| 저장소·배포 | GitLab, GitLab Flow: `main`(개발) → `pre-production`(스테이징) → `production` |

## Oracle 11g 규칙 (ADR-001)

- 금지 문법: `OFFSET ... ROWS`, `FETCH FIRST/NEXT`, `LIMIT`, `GENERATED ... AS IDENTITY`, `CROSS/OUTER APPLY`, `JSON_*` 함수, `DROP ... IF EXISTS`, `SELECT TOP`, `ILIKE`, SQL 컬럼 타입 `BOOLEAN`
- 페이징은 ROWNUM 중첩 패턴만 쓴다. 매퍼마다 직접 쓰지 않고 공통 MyBatis 인터셉터가 감싼다 (ADR-003). 총 건수는 매퍼에 `count{이름}` 메서드로 명시한다.
- MyBatis 는 `#{}` 바인딩을 쓴다. `${}` 는 식별자 화이트리스트가 있을 때만 쓴다 (SQL 인젝션 방지).
- `mybatis.configuration.jdbc-type-for-null=NULL` 설정이 필수다.
- JDBC 드라이버 버전은 ADR-002 상태가 "확정"일 때만 고정값으로 쓴다.

## 공통 응답·예외

- 응답은 `CommonApiResponse` 래퍼로 감싼다.
- 예외는 `@RestControllerAdvice` 한 곳에서 표준 응답으로 변환한다.

## 보안

- 시크릿은 환경변수 `${...}` 참조로만 둔다. 리터럴 값은 쓰지 않는다. Write·Edit 는 쓰기 단계에서, 커밋은 커밋 단계(Claude 커밋 훅과 git `pre-commit` 훅)에서 차단한다. Bash 로 쓴 파일은 쓰기 단계 검사를 거치지 않으므로 커밋 단계에서 걸린다.
- 시크릿 탐지는 정규식 기반이다. 설정 파일(`.properties`, `.yml`, `.env`)은 시크릿 키의 값이 리터럴이면 문자만으로 되어 있어도 차단하지만, 코드 안의 문자만으로 된 값은 놓칠 수 있다. 리뷰에서도 확인한다.
- 실제 시크릿 값이 든 `.env` 는 사람이 직접 만들고 Git 에서 제외한다. 에이전트는 `.env.example` 에 플레이스홀더만 쓴다.
- CORS 는 Origin allowlist 로 운영한다. WebView 의 Origin 값은 실측 후 허용 규칙을 정한다.
- CSRF 정책은 Refresh Token 전달 방식(헤더 또는 쿠키)이 정해진 뒤 확정한다.

## 하네스 운영

- 에이전트: backend / frontend / mobile / infra 영역 × analyzer / developer / reviewer 역할 12종, 그리고 `harness-keeper`
- 스킬: `harness-review`(하네스 변경 검토), `oracle-compat-check`(Oracle 호환 정적 검사)
- 훅: `.claude/hooks/guard-content.mjs` 가 Oracle 금지 문법과 하드코딩 시크릿을 세 곳에서 같은 규칙으로 차단한다.
  - Write·Edit·MultiEdit: 새로 쓰는 내용
  - Bash 의 `git commit`: 커밋될 파일 전체 (`-a` 커밋이면 스테이징하지 않은 수정본 포함)
  - git `pre-commit` 훅(`.githooks/pre-commit`): 스테이징된 파일 전체. 사람이 직접 커밋해도 걸린다. 저장소마다 한 번 `git config core.hooksPath .githooks` 로 켠다.
- 보고 위치: 에이전트 보고 파일은 `.claude/reports/` 에 쓴다. Git 에서 제외된다. 리뷰어의 `Write` 는 이 위치에만 쓴다.
- 원칙: `.claude/philosophy.md`
- 우회 경로 (명시적이고 눈에 보이는 형태만 허용)
  - Oracle 문법 예외: 파일 안에 `harness-guard: allow(oracle) <사유>` 한 줄. 사유가 없으면 무효다. 하네스 리뷰에서 전수 확인한다.
  - 시크릿: 우회 경로 없음. 환경변수 참조로 바꾼다.
  - 훅 전체 끄기: 환경변수 `HARNESS_SKIP_GUARD=1`. Claude 훅에만 적용된다. 본인 세션에서만 쓰고, 사유를 작업 기록에 남긴다.
  - `git commit --no-verify` 는 git 훅만 건너뛴다. 쓰지 않는다. Claude 세션의 커밋은 이 옵션과 상관없이 검사된다.
- 모델 티어 (외부 하네스 정책을 따름)
  - analyzer · reviewer: `sonnet`, effort `high`
  - developer: `sonnet`, effort `xhigh`
  - harness-keeper: `inherit`, effort 지정 안 함
  - `haiku` 에는 effort 를 넣지 않는다. `inherit` 에도 effort 를 넣지 않는다.

## 금지

- 설계 문서의 값(드라이버 버전 등)을 검증 없이 확정으로 표기하는 것
- 시크릿 리터럴을 파일이나 커밋에 남기는 것
- 차단이 가능한 규칙을 문서 주의에만 기대는 것 (훅으로 막을 수 있으면 훅으로 막는다)
