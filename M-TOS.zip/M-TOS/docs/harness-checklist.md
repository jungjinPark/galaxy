# 하네스 후속 체크리스트

Written for: 프로젝트 리더와 하네스 관리자. 하네스 구성 중 확정되지 않았거나 실제 환경에서 확인되지 않은 항목을 추적한다.

각 항목은 확정되거나 확인되면 체크하고, 해당 에이전트 파일 또는 CLAUDE.md 를 함께 고친다. 확정 값은 추측하지 않고 결정한 사람을 기록한다.

## A. 확정 후 수정 (미확정 항목)

| ☐ | 항목 | 결정할 사람 | 반영 위치 |
|---|---|---|---|
| ☐ | Access · Refresh Token 저장 위치 (브라우저, 네이티브) | 보안 담당 | `frontend-developer` 6절, `frontend-reviewer` FE-AUTH-01, `mobile-developer` 7절 |
| ☐ | Refresh Token 전달 방식 (쿠키 또는 메시지) 과 CSRF 정책 | 보안 담당 | CLAUDE.md 보안 절, `mobile-analyzer` 7절, `backend-developer` 7절 |
| ☐ | WebView 가 보내는 Origin 값 (플랫폼별 실측) | 모바일 담당 | `mobile-analyzer` 4절, `backend-developer` CORS 항목 |
| ☐ | CORS 허용 Origin 목록 | 백엔드 · 모바일 담당 | `backend-developer` 7절, `backend-reviewer` BE-SEC-03 |
| ☐ | `--dart-define` 으로 앱에 넣어도 되는 값 목록 | 모바일 담당 | `mobile-analyzer` 8절, `mobile-reviewer` MOB-SEC-02 |
| ☐ | 마이그레이션 도구와 실행 시점 (앱 기동 시 자동 또는 별도 단계) | 백엔드 담당 | `backend-analyzer` 3절, `infra-analyzer` 9절, `infra-developer` |
| ☐ | 백엔드 빌드 파일(`build.gradle`)과 Gradle 명령 확인 | 백엔드 담당 | `backend-reviewer` Step 2 |
| ☐ | 공통 응답 · 예외 · ErrorCode 명세 (`CommonApiResponse`, 예외 클래스) | 백엔드 담당 | `backend-developer` 5절 (공통), `backend-analyzer` 5절 |
| ☐ | 백엔드 패키지 `{basePackage}` 와 도메인 목록 | 백엔드 담당 | `backend-developer` 3절, `backend-analyzer` 2절 |
| ☐ | 프론트엔드 디렉터리 구조와 타겟 경로 규칙 | 프론트엔드 담당 | `frontend-analyzer` 1절, `frontend-developer` |
| ☐ | 프론트엔드 검증 명령 (`package.json` 스크립트) | 프론트엔드 담당 | `frontend-reviewer` Step 2, `frontend-developer` 9절 |
| ☐ | 프론트엔드 디자인 토큰과 스타일 규칙 | 프론트엔드 담당 | `frontend-developer` 스타일 절 |
| ☐ | 모바일 검증 명령과 플랫폼 설정 (`pubspec.yaml`, flavor) | 모바일 담당 | `mobile-reviewer` Step 2, `mobile-developer` 설정 절 |
| ☐ | 테스트 방식 (프론트엔드 단위 테스트, 모바일 메시지 핸들러 테스트) | 각 영역 담당 | `frontend-reviewer` FE-STR-02, `mobile-reviewer` MOB-STR-02 |
| ☐ | 중앙 등록부 위치 (라우트, 메뉴, 다국어 키) | 프론트엔드 담당 | `frontend-developer` 구조 절 |
| ☐ | DB `processes` 실측값과 커넥션 풀 크기 | 인프라 담당 | `infra-analyzer` 3절, `infra-reviewer` INF-POOL |
| ☐ | Oracle XE 기동 완료 판정 방법 (헬스체크) | 인프라 담당 | `infra-analyzer` 2절, `infra-developer` |
| ☐ | Oracle XE 이미지 태그 고정 방식 (메이저 버전 기준 확정) | 인프라 담당 | `infra-developer` 이미지 절 |
| ☐ | 운영 배포 승인자와 승인 기록 위치 | 인프라 담당 | `infra-analyzer` 6절, `infra-developer` 파이프라인 절 |
| ☐ | JDBC 드라이버 버전 (ADR-002) | 백엔드 담당 | ADR-002, CLAUDE.md Oracle 절 |
| ☐ | 첫 기능 슬라이스 확정 (백엔드 기준 슬라이스) | 사용자 검토 | `backend-developer` 2절 |
| ☐ | 템플릿 확정 (AA 협의) | AA | `backend-developer` 부록 A |
| ☐ | 리뷰·PR 서비스 결정과 GitLab MR 연동 스킬 추가 | 프로젝트 리더 | `harness-review` 보류 항목, 신규 스킬 |
| ☐ | 공통 페이징 인터셉터 구현 (ADR-003) | 백엔드 담당 | 공통 모듈, `backend-developer` 페이징 절, `backend-reviewer` BE-ORA-03 |

## B. 실 개발 환경에서 동작 확인

### B-1. 훅과 쓰기 검사

| ☐ | 확인 항목 | 방법 | 기대 결과 |
|---|---|---|---|
| ☐ | Claude Code 세션에서 Oracle 금지 문법 쓰기가 실제로 차단되는지 | 매퍼 XML 에 `OFFSET ... ROWS` 를 쓰도록 요청 | 쓰기 취소, 규칙 ID 표시 |
| ☐ | 시크릿 리터럴 쓰기가 실제로 차단되는지 | 설정 파일에 키-값 리터럴 쓰기 요청 | 쓰기 취소 |
| ☐ | `harness-guard` 마커 사유 없음 → 차단, 사유 있음 → 통과 | 실제 파일로 확인 | 샘플 입력 결과와 일치 |
| ☐ | 실제 코드에서 오탐이 있는지 | 첫 구현 후 쓰기 검사 결과 검토 | 오탐이 있으면 `harness-keeper` 에 보고 |
| ☐ | Claude 세션의 `git commit` 이 위반 파일에서 차단되는지 | Bash 로 위반 파일을 만들고 커밋 요청 | 커밋 취소, 규칙 ID 표시 |
| ☐ | 작업자 저장소마다 git 훅이 켜져 있는지 | `git config core.hooksPath` 결과 확인 | `.githooks` |
| ☐ | 사람이 직접 커밋할 때 위반 파일이 차단되는지 | 터미널에서 위반 파일 커밋 | 커밋 중단 |
| ☐ | node 가 없는 환경에서 git 훅이 커밋을 막는지 | node 없는 PATH 로 커밋 | 커밋 중단 (통과하지 않음) |
| ☐ | 리뷰어가 `.claude/reports/` 밖에 파일을 쓰지 않는지 | 리뷰 실행 후 `git status` 확인 | 보고 파일 외 변경 없음 |

### B-2. 에이전트 동작

| ☐ | 확인 항목 | 방법 | 기대 결과 |
|---|---|---|---|
| ☐ | analyzer 가 Handoff 0~9절을 빠짐없이 산출하는지 | 샘플 요구사항 1건 분석 | 9개 절 모두 존재, 참조 파일 경로 실재 확인 표시 |
| ☐ | developer 가 Handoff 가 불완전하면 구현을 멈추는지 | 8절을 비운 Handoff 를 전달 | 구현하지 않고 되돌림 |
| ☐ | reviewer 가 검증 명령을 실제로 실행하는지 | 샘플 변경에 검토 실행 | 명령 결과 기록, 직접 실행 확인 |
| ☐ | reviewer 가 코드를 수정하지 않는지 | 지적이 있는 변경에 검토 실행 | 파일 변경 없음 |
| ☐ | 에이전트 도구 허용 목록으로 검증 명령이 막히지 않는지 | 백엔드, 인프라 reviewer 실행 | `./gradlew`, `docker compose config` 실행 가능 |

### B-3. 백엔드

| ☐ | 확인 항목 | 방법 | 기대 결과 |
|---|---|---|---|
| ☐ | 백엔드 템플릿 T-01~T-06 이 컴파일되는지 | 첫 슬라이스 구현 시 빌드 | 컴파일 성공 (템플릿 확정 후) |
| ☐ | 매퍼 테스트가 실제 Oracle 11g 에서 실행되는지 | `gvenzl/oracle-xe:11` 기동 후 `@MybatisTest` 실행 | 통과, H2 로 대체되지 않음 |
| ☐ | 페이징 쿼리가 11g 에서 동작하는지 | 경계 값(첫 페이지, 마지막 페이지) 테스트 | 결과 일치 |
| ☐ | `jdbc-type-for-null=NULL` 설정 전후의 null 바인딩 차이 | 설정을 끄고 켜며 비교 | ADR-002 에 결과 기록 |
| ☐ | 드라이버 버전이 실제로 적용되는지 | `./gradlew dependencies` 로 로드 버전 확인 | 고정한 버전과 일치 |
| ☐ | Graceful Shutdown 이 요청을 끝까지 처리하는지 | 처리 중 종료 신호 전송 | 진행 중 요청 완료 후 종료 |
| ☐ | Refresh Token 재사용 감지 | 폐기된 토큰으로 재발급 시도 | 세션 전체 폐기 |

### B-4. 프론트엔드

| ☐ | 확인 항목 | 방법 | 기대 결과 |
|---|---|---|---|
| ☐ | 토큰 갱신이 동시 요청에서 한 번만 나가는지 | 여러 요청을 동시에 만료 상태로 발생 | 갱신 요청 1회 |
| ☐ | 갱신 실패 시 로그인 화면으로 이동하는지 | 갱신 토큰을 무효화 후 요청 | 로그인 화면 |
| ☐ | 라우트 가드가 인증 없는 접근을 막는지 | 로그아웃 후 보호 경로 직접 입력 | 로그인 화면으로 이동 |
| ☐ | `VITE_` 번들에 시크릿이 없는지 | 빌드 결과물 검색 | 시크릿 문자열 없음 |

### B-5. 모바일

| ☐ | 확인 항목 | 방법 | 기대 결과 |
|---|---|---|---|
| ☐ | 실기기에서 WebView Origin 값 측정 | 플랫폼별 기기에서 API 호출 로그 확인 | 측정값을 `mobile-analyzer` 4절에 기록 |
| ☐ | 허용 목록 밖 URL 로 이동이 차단되는지 | 외부 링크 클릭 | 이동 차단 |
| ☐ | 검증되지 않은 JS Channel 메시지가 무시되는지 | 형식이 틀린 메시지 전송 | 처리되지 않고 기록만 남음 |
| ☐ | 로그아웃 시 서버의 푸시 토큰이 삭제되는지 | 로그아웃 후 서버 상태 확인 | 토큰 삭제 |
| ☐ | 알림 탭 시 서버가 검증한 화면으로만 이동하는지 | 조작된 알림 페이로드로 테스트 | 임의 화면으로 이동하지 않음 |
| ☐ | Android 와 iOS 의 동작 차이 | 두 플랫폼에서 같은 시나리오 실행 | 차이를 Handoff 9절에 기록 |

### B-6. 인프라

| ☐ | 확인 항목 | 방법 | 기대 결과 |
|---|---|---|---|
| ☐ | `docker compose config` 가 성공하는지 | 구성 파일 검증 | 성공, 시크릿 값 없음 |
| ☐ | 컨테이너 재생성 후 Oracle 데이터가 남는지 | 데이터 입력 후 `down`, `up` | 데이터 유지 (볼륨 선언 확인) |
| ☐ | Oracle XE 기동 완료 판정이 정확한지 | 헬스체크 통과 시점과 실제 접속 가능 시점 비교 | 헬스체크 통과 후 접속 가능 |
| ☐ | 의존 서비스 순서가 지켜지는지 | 전체 기동 후 로그 확인 | DB 준비 후 애플리케이션 기동 |
| ☐ | 커넥션 풀이 `processes` 한도 안에 드는지 | 인스턴스 수를 늘려 접속 수 확인 | 한도 이내 |
| ☐ | GitLab CI 브랜치 규칙과 수동 승인이 동작하는지 | 테스트 브랜치로 파이프라인 실행 | 규칙대로 단계 실행, 운영 단계 수동 |
| ☐ | 테스트 컨테이너가 다른 작업의 컨테이너를 지우지 않는지 | 두 프로젝트 이름으로 동시 실행 | 서로 영향 없음 |

## C. 완료 기준

- A 항목이 모두 체크되면 해당 에이전트의 `[미확정]` 표기를 제거하고 구현 차단 조건을 푼다.
- B 항목은 실 환경에서 확인된 뒤 결과(날짜, 측정값, 확인자)를 옆에 적는다. 확인하지 않은 항목을 통과로 표시하지 않는다.
- 기준이 바뀌면 이 문서와 해당 에이전트 파일을 같은 커밋에서 고친다.
