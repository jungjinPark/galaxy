# M-TOS 하네스 작업자 가이드

Written for: M-TOS 프로젝트에 참여하는 개발자와 리뷰어. 하네스를 처음 쓰거나 막혔을 때 먼저 읽는 문서다.

## 1. 하네스가 무엇인가

M-TOS 는 Claude Code 가 이 프로젝트의 규칙을 지키며 일하도록 만든 설정 묶음이다. 세 부분으로 구성된다.

| 구성 | 위치 | 역할 |
|---|---|---|
| 프로젝트 지침 | `CLAUDE.md` | 기술 스택, Oracle 11g 규칙, 보안 규칙, 우회 경로 |
| 에이전트·스킬 | `.claude/agents/`, `.claude/skills/` | 영역별 작업 담당과 검토 절차 |
| 쓰기 차단 훅 | `.claude/hooks/guard-content.mjs` | 금지 문법과 시크릿 리터럴을 파일 쓰기 단계에서 차단 |

설계 근거는 `docs/adr/` 에 있다. 원칙은 `.claude/philosophy.md` 에 있다.

> 현재 저장소에는 애플리케이션 코드가 없다. 코드가 들어오기 전까지 리뷰 에이전트는 검토할 대상이 없다.

## 2. 처음 시작하기

1. 저장소를 받고 `M-TOS` 디렉터리에서 Claude Code 를 실행한다.
2. 훅이 켜져 있는지 `/hooks` 에서 `PreToolUse` 항목에 `guard-content.mjs` 가 보이는지 확인한다. `Write|Edit|MultiEdit` 와 `Bash` 두 항목이 있어야 한다.
3. git 커밋 관문을 켠다. 저장소마다 한 번만 하면 된다.

   ```bash
   git config core.hooksPath .githooks
   ```

4. `CLAUDE.md` 를 한 번 읽는다. 특히 "Oracle 11g 규칙"과 "보안" 절을 본다.
5. 자신이 맡을 영역(backend / frontend / mobile / infra)의 analyzer 와 developer 를 확인한다.

## 3. 작업 흐름

기능 하나는 보통 아래 순서로 간다.

```
요구사항 → [영역]-analyzer (설계) → [영역]-developer (구현) → [영역]-reviewer (검토) → MR
```

| 단계 | 에이전트 | 하는 일 | 파일 수정 |
|---|---|---|---|
| 설계 | `backend-analyzer` 등 | 영향 범위, 설계 결정, 미확인 항목 정리 | 없음 |
| 구현 | `backend-developer` 등 | 설계된 범위만 구현, 테스트 실행 | 있음 |
| 검토 | `backend-reviewer` 등 | 규칙 위반, 보안, 테스트 근거 확인 | 없음 (지적만) |

요청할 때 영역과 단계를 함께 적으면 된다. 예시:

- "backend-analyzer 로 회원 목록 페이징 설계를 해줘"
- "설계대로 backend-developer 로 구현해줘"
- "방금 변경을 backend-reviewer 로 검토해줘"

설계 단계에서 확인되지 않은 항목은 "미확인"으로 남긴다. 추측으로 채우지 않는다.

## 4. Oracle 11g 규칙 (가장 자주 걸리는 부분)

고객 DB 는 Oracle 11g R2 다. 12c 이상 문법은 11g 에서 실행되지 않는다.

### 쓰면 안 되는 문법

| 문법 | 대신 쓰는 것 |
|---|---|
| `OFFSET ... ROWS`, `FETCH FIRST/NEXT` | 공통 페이징 (`PageRequest`, ADR-003) |
| `LIMIT` | 공통 페이징 (`PageRequest`, ADR-003) |
| `GENERATED ... AS IDENTITY` | SEQUENCE 와 `NEXTVAL` |
| `CROSS APPLY`, `OUTER APPLY` | 서브쿼리 또는 조인 |
| `JSON_*` 함수 | 애플리케이션에서 처리 |
| `DROP ... IF EXISTS` | PL/SQL 블록으로 존재 여부 확인 후 삭제 |
| `SELECT TOP` | 공통 페이징 (`PageRequest`, ADR-003) |
| `ILIKE` | `UPPER(...) LIKE UPPER(...)` |
| SQL 컬럼 타입 `BOOLEAN` (`.sql` 파일) | `NUMBER(1)` 또는 `CHAR(1)` |

### 페이징 (ADR-003)

매퍼에 ROWNUM 래퍼를 직접 쓰지 않는다. 공통 MyBatis 인터셉터가 감싼다.

- 페이징할 조회의 파라미터에 `PageRequest`(페이지 번호, 페이지 크기)를 넣는다.
- 매퍼에는 원래 SQL 만 쓴다. `ORDER BY` 를 반드시 넣고, 정렬이 유일하지 않으면 기본키를 마지막에 붙인다.
- 총 건수는 같은 검색 조건으로 `count{이름}` 메서드를 따로 둔다. 검색 조건은 `<sql>` 조각 하나로 두 쿼리가 함께 쓴다.
- `RowBounds` 로 페이징하지 않는다. DB 가 아니라 메모리에서 건너뛰는 방식이라 전체 행을 읽는다.
- 인터셉터는 공통 명세가 확정된 뒤 구현한다. 그 전에는 페이징 조회를 구현하지 않는다.

### 매퍼 바인딩

- 값은 `#{}` 로 바인딩한다.
- `${}` 는 식별자 화이트리스트가 있을 때만 쓴다. 사용자 입력을 `${}` 로 넣으면 SQL 인젝션이 된다.
- null 바인딩 설정 `jdbc-type-for-null=NULL` 을 지우지 않는다.

## 5. 훅이 막을 때 (자주 묻는 질문)

훅은 두 시점에 검사한다.

- 파일을 쓰는 순간 (Claude 의 Write·Edit)
- 커밋하는 순간 (Claude 의 `git commit`, 사람이 직접 하는 커밋 모두). Bash 나 편집기로 쓴 파일도 여기서 걸린다.

위반이 있으면 쓰기나 커밋이 취소되고 아래 같은 메시지가 나온다.

```
[guard-content] 쓰기 차단: src/main/resources/mapper/A.xml
  L1 [ORA-OFFSET] OFFSET ... ROWS 는 12c+ 문법. 공통 페이징(PageRequest, ADR-003)을 쓴다
```

메시지의 규칙 ID 를 보고 대응한다.

| 규칙 ID 접두사 | 의미 | 대응 |
|---|---|---|
| `ORA-` | Oracle 11g 비호환 문법 | 위 표의 대체 문법으로 고친다 |
| `SEC-` | 하드코딩된 시크릿처럼 보이는 값 | 환경변수 참조 `${...}` 로 바꾼다 |

### Oracle 문법 예외가 꼭 필요할 때

파일 안에 **같은 줄에 사유를 붙여서** 아래 마커를 넣는다.

```
-- harness-guard: allow(oracle) 12c 이상 DB 에서만 실행되는 마이그레이션 검증용
```

- 사유가 없으면 무효다. 차단된다.
- 마커는 하네스 리뷰에서 전수 확인한다. 사유가 약하면 리뷰에서 빠진다.

### 시크릿은 우회가 없다

- 시크릿 리터럴에는 마커 우회가 없다. 환경변수 참조로 바꾼다.
- 실제 값은 `.env` 에 두고 Git 에서 제외된다. `.env.example` 에는 값을 비운 형태만 쓴다.
- 플레이스홀더 `${DB_PASSWORD}` 는 통과한다.

### 오탐(잘못 막힘)으로 보이면

1. 차단 메시지의 규칙 ID 와 줄 번호를 확인한다.
2. 정말 규칙 위반이 아닌지 먼저 확인한다. 대부분은 위반이다.
3. 오탐이 맞으면 작업을 멈추고 `harness-keeper` 에게 알린다. 정규식을 고치는 일은 하네스 변경이므로 본인이 임의로 고치지 않는다.

### 훅 전체를 끄는 방법

`HARNESS_SKIP_GUARD=1` 환경변수로 Claude 훅을 끌 수 있다. 본인 세션에서만 쓰고, 사유를 작업 기록에 남긴다. 팀 설정 파일에 넣지 않는다.

이 변수는 git `pre-commit` 훅에는 적용되지 않는다. `git commit --no-verify` 로 git 훅을 건너뛰지 않는다.

## 6. 하네스 파일을 바꿀 때

`CLAUDE.md`, `.claude/`, `docs/adr/` 를 수정하는 작업은 하네스 변경이다. 아래 순서를 따른다.

1. 변경한다.
2. `harness-review` 스킬로 검토한다. 의미 충돌과 사실 정확성을 함께 본다.
3. 쓰기 검사를 통과하는지 확인한다.

   ```bash
   node .claude/hooks/guard-content.mjs --scan CLAUDE.md docs .claude
   ```

4. 리뷰 결과를 반영하고 커밋한다. 커밋 메시지에 무엇을 바꿨는지와 근거를 적는다.

ADR 을 새로 쓰거나 기존 ADR 을 바꾸는 일은 사용자 승인이 필요하다. 확정된 ADR 원문은 수정하지 않는다.

## 7. 시크릿 관리

| 항목 | 규칙 |
|---|---|
| 실제 값 | `.env` 에만 둔다. Git 에 올리지 않는다. |
| 예시 파일 | `.env.example` 에 키 이름과 빈 값만 둔다. |
| 코드와 설정 | 환경변수 참조 `${...}` 만 쓴다. 리터럴을 쓰지 않는다. |
| 프론트엔드 | `VITE_` 로 시작하는 값은 브라우저에 노출된다. 시크릿을 넣지 않는다. |
| 모바일 | 시크릿은 앱에 넣지 않는다. `--dart-define` 값도 앱 바이너리에 들어갈 수 있으므로 시크릿은 서버가 보관한다. 앱에는 공개 가능한 값만 둔다. |

시크릿 탐지는 정규식 기반이라 모든 형태를 잡지 못한다. 설정 파일(`.properties`, `.yml`, `.env`)은 시크릿 키의 값이 리터럴이면 문자만으로 되어 있어도 막지만, 코드 안의 문자만으로 된 값은 놓칠 수 있다. 훅이 통과시켰다고 안전한 것이 아니므로 리뷰에서도 확인한다.

## 8. 아직 확정되지 않은 것

미확정 항목과 실 환경 확인 항목은 `docs/harness-checklist.md` 한 곳에서 관리한다. 이 가이드에는 목록을 따로 두지 않는다.

- 확정 전에는 임의로 값을 쓰지 않는다. 그 값이 필요하면 체크리스트의 "결정할 사람"에게 확인을 요청한다.
- 미확정 항목을 설계나 구현에 쓰면 리뷰에서 지적된다.

## 9. 에이전트 모델 정책 (하네스 관리자용)

| 역할 | 모델 | effort |
|---|---|---|
| analyzer, reviewer | `sonnet` | `high` |
| developer | `sonnet` | `xhigh` |
| harness-keeper | `inherit` | 지정 안 함 |

`haiku` 에는 effort 를 넣지 않는다. `inherit` 에도 effort 를 넣지 않는다. 작업자가 호출 시 모델을 올리지 않는다. 티어는 에이전트 파일 frontmatter 에서만 바꾼다.

## 10. 문제가 생겼을 때

| 증상 | 확인할 것 |
|---|---|
| 훅이 동작하지 않는 것 같다 | `/hooks` 에서 `PreToolUse` 항목 확인. 새 세션에서 다시 확인. |
| 에이전트가 목록에 없다 | `.claude/agents/` 에 파일이 있는지, 세션을 새로 열었는지 확인 |
| 쓰기 검사가 위반을 보고했다 | 위 5절의 규칙 ID 별 대응 |
| git 명령이 실패한다 | 저장소 루트(`M-TOS`)에서 실행했는지 확인 |
| 규칙이 서로 맞지 않는 것 같다 | `harness-keeper` 에게 `harness-review` 를 요청 |

## 관련 문서

- `CLAUDE.md`: 프로젝트 지침 전체
- `.claude/philosophy.md`: 하네스 설계 원칙
- `docs/adr/ADR-001_oracle-11g-constraints.md`: Oracle 11g 제약 (Accepted)
- `docs/adr/ADR-002_jdbc-driver-pinning.md`: JDBC 드라이버 고정 (Proposed, 미검증)
- `docs/adr/ADR-003_pagination-interceptor.md`: 페이징 공통화 (Accepted, 구현 대기)
