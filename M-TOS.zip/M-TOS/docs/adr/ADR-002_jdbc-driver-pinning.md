# ADR-002: JDBC 드라이버 버전 고정

## Status

Proposed — 미검증 (2026-10-18). 11g 호환 스파이크 전까지 "확정"이 아니다.

## Context

Spring Boot 3.5 BOM 은 Oracle JDBC 드라이버를 23.x 로 관리한다. 설계 문서는 이 버전이 11g 를 공식 지원하지 않는다고 본다.
그래서 `oracle-database.version` 속성으로 21.x 를 고정하는 안이 나왔다.

다만 아래 두 가지가 아직 확인되지 않았다.

- 21.x 가 11.2.0.4 서버를 공식 지원하는지 (Oracle 인증 매트릭스 확인 필요)
- `oracle-database.version` 속성이 실제로 BOM 의 드라이버 버전을 바꾸는지

## Decision (잠정)

- 드라이버는 ojdbc8 계열로 쓰고 버전은 21.x 로 고정한다. 단, 아래 검증을 통과하기 전까지 잠정 결정이다.
- 대안으로 ojdbc8 의 다른 버전도 같은 검증으로 비교한다.

## Verification (스파이크)

1. `./gradlew dependencies` 로 실제로 로드되는 드라이버 버전을 확인한다. 속성명이 틀리면 23.x 가 그대로 들어온다.
2. 실제 11.2.0.4 (또는 `gvenzl/oracle-xe:11`) 에 접속한다.
3. 아래를 확인하고 결과를 이 ADR 에 기록한다.
   - null 바인딩: `jdbc-type-for-null=NULL` 설정 전후 차이
   - ROWNUM 중첩 페이징 쿼리 결과
   - 커넥션 풀 재연결 (max-lifetime 동작)
4. Oracle 인증 매트릭스에서 해당 드라이버와 11.2.0.4 의 지원 여부를 확인하고 링크를 남긴다.
5. 결과에 따라 Status 를 Accepted 로 바꾸거나 버전을 다시 정한다.

## Consequences

- 검증 전에는 `pom`·`build.gradle` 에 드라이버 버전을 고정값으로 쓰지 않는다.
- 검증 결과가 나오면 ADR-001 과 CLAUDE.md 의 Oracle 규칙을 같이 갱신한다.

## Related

- [ADR-001](ADR-001_oracle-11g-constraints.md): Oracle 11g 호환 제약
