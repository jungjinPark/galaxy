# ADR-003: Oracle 11g 페이징 공통화 (MyBatis 인터셉터)

## Status

Accepted (2026-10-18). 구현은 공통 응답·예외 명세(`CommonApiResponse`, 예외 클래스, `ErrorCode`)가 확정된 뒤 시작한다.

## Context

ADR-001 은 페이징을 ROWNUM 중첩 패턴으로 쓰도록 정했다. 이 패턴을 매퍼마다 손으로 쓰면 다음 위험이 있다.

- 같은 래퍼를 매퍼 수만큼 복사하게 되고, 정렬 기준이나 행 번호 계산이 어긋날 수 있다.
- 규칙이 바뀌면(예: 열 이름, 정렬 규칙) 모든 매퍼를 고쳐야 한다.
- 검토자가 매퍼마다 래퍼가 맞는지 확인해야 한다.

검토한 방법은 다음과 같다.

| 방법 | 결과 |
|---|---|
| 자체 MyBatis 인터셉터 | **채택** |
| PageHelper 도입 | 보류. 라이선스 비용은 없으나(MIT), Spring Boot 3.5 와 Oracle 11g 호환을 실측하지 않았다. `PageHelper.startPage()` 는 다음 한 번의 쿼리에만 적용되는 ThreadLocal 방식이라 호출 순서 규칙이 필요하다. 필요해지면 다시 검토한다. |
| `<sql>` 조각과 `<include>` | 불가. 안쪽 SELECT 가 매퍼마다 달라 감싸는 조각으로 재사용할 수 없다. |
| `${}` 로 래퍼 문자열 조립 | 기각. SQL 인젝션 규칙(CLAUDE.md)에 어긋난다. |
| MyBatis `RowBounds` | 기각. DB 에서 페이징하지 않고 메모리에서 건너뛰어 대량 테이블에서 전체 행을 읽는다. |

## Decision

### 1. 요청 객체

페이징 대상 조회의 파라미터는 `PageRequest` 를 포함한다. 필드는 `pageNo`(1부터 시작)와 `pageSize` 다. 시작·끝 행 번호는 인터셉터가 계산한다.

- `startRow = (pageNo - 1) * pageSize + 1`
- `endRow = pageNo * pageSize`

### 2. 인터셉터

`Executor.query` 를 가로채서, 파라미터에 `PageRequest` 가 있을 때만 원래 SQL 을 다음 형태로 감싼다.

```sql
SELECT * FROM (
  SELECT a.*, ROWNUM AS ROW_NUM_ FROM (
    <원래 SQL>
  ) a WHERE ROWNUM <= #{endRow}
) WHERE ROW_NUM_ >= #{startRow}
```

- 행 번호 열 이름은 `ROW_NUM_` 로 고정한다. 원래 SQL 의 열과 겹치지 않도록 하기 위함이다.
- 원래 SQL 끝의 `;` 는 래퍼 생성 전에 제거하고, 남아 있으면 실패로 처리한다.
- `ORDER BY` 는 원래 SQL 안에 둔다.
- 래퍼 문자열은 인터셉터 코드의 상수로만 만든다. 사용자 입력을 래퍼 문자열에 넣지 않는다.

### 3. 총 건수

총 건수는 매퍼에 명시한다. 같은 검색 조건으로 `COUNT(*)` 를 세는 별도 매퍼 메서드를 두고, 이름은 `count{이름}` 으로 짓는다. 인터셉터가 원래 SQL 을 감싸서 자동으로 세지 않는다.

### 4. 정렬

- 페이징 대상 조회는 `ORDER BY` 를 반드시 가진다.
- 정렬 기준이 유일하지 않으면 기본키를 마지막 기준으로 덧붙인다.
- 인터셉터는 정렬 유일성을 검사하지 않는다. 리뷰 규칙 BE-ORA-04 로 확인한다.

### 5. 금지

- `RowBounds` 로 페이징하지 않는다.
- 래퍼 문자열 생성에 `${}` 를 쓰지 않는다.
- 페이징 대상 조회에 `OFFSET`, `FETCH`, `LIMIT` 을 쓰지 않는다 (ADR-001).

## Consequences

- 페이징 래퍼 규칙은 인터셉터 한 곳에 모인다. 규칙이 바뀌면 그 파일만 고친다.
- 매퍼는 원래 SQL 과 총 건수 쿼리만 쓴다.
- 인터셉터 유지보수 책임은 우리에게 있다. 라이선스 비용은 없지만, 버그 수정과 Oracle 버전 대응을 직접 한다.
- 인터셉터 자체는 Oracle 11g 실제 DB 에서 테스트해야 한다. H2 로는 ROWNUM 동작을 확인할 수 없다.
- 인터셉터가 `PageRequest` 를 찾지 못한 조회는 래퍼 없이 그대로 실행된다. 페이징이 필요한 조회인데 파라미터 타입이 빠지면 전체 행이 반환되므로, 매퍼 테스트에서 경계 값으로 확인한다.

## Enforcement

- 구현: 공통 모듈의 MyBatis 인터셉터 (구현 대기)
- 리뷰: `backend-reviewer` 의 BE-ORA-03, BE-ORA-04
- 테스트: 첫 페이지, 마지막 페이지, 빈 결과, 총 건수 일치를 실제 Oracle 11g 에서 확인
- 체크리스트: `docs/harness-checklist.md` B-3 항목

## Related

- [ADR-001](ADR-001_oracle-11g-constraints.md): Oracle 11g 제약. 페이징 패턴의 근거.
- [ADR-002](ADR-002_jdbc-driver-pinning.md): JDBC 드라이버 고정 (미검증).
