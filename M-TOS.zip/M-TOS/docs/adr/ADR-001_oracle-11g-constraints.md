# ADR-001: Oracle 11g R2 호환 제약

## Status

Accepted (2026-10-18). 고객 요청 설계 문서 기준이다.

## Context

고객사 DB는 Oracle 11g R2다. MyBatis 3.5 를 쓰며, 페이징과 null 바인딩이 실제 위험 지점이다.
12c 이상에서 추가된 문법은 11g 에서 구문 오류가 나므로, 개발 중에는 통과하고 배포 후 깨질 수 있다.

## Decision

1. 다음 문법을 쓰지 않는다. 쓰면 쓰기 단계에서 훅이 차단한다.
   - `OFFSET ... ROWS`, `FETCH FIRST/NEXT`, `LIMIT`
   - `GENERATED ... AS IDENTITY`
   - `CROSS APPLY`, `OUTER APPLY`
   - `JSON_*` 함수
   - `DROP ... IF EXISTS`
   - `SELECT TOP`, `ILIKE`
   - SQL 컬럼 타입 `BOOLEAN`
2. 페이징은 ROWNUM 중첩 패턴을 쓴다.

   ```sql
   SELECT * FROM (
     SELECT a.*, ROWNUM AS rn FROM (
       SELECT ... FROM ... ORDER BY ...
     ) a WHERE ROWNUM <= #{endRow}
   ) WHERE rn >= #{startRow}
   ```

3. MyBatis 는 `#{}` 를 쓴다. `${}` 는 식별자 화이트리스트가 있을 때만 쓴다.
4. `mybatis.configuration.jdbc-type-for-null=NULL` 을 설정한다. 설정하지 않으면 null 바인딩에서 ORA-17004 가 날 수 있다.
   이 원인 설명은 고객 설계 문서 기준이며, 이 저장소에서는 미검증이다. ADR-002 스파이크에서 확인한다.

## Consequences

- 12c 이상 문법을 쓸 수 없다. 고객이 DB 를 업그레이드하면 이 ADR 을 다시 검토한다.
- 훅 차단은 Java·XML·SQL·Kotlin 파일에만 걸린다. 매퍼 밖 SQL 문자열도 같은 확장자면 검사된다.
- 예외는 파일 안 `harness-guard: allow(oracle) <사유>` 로만 허용하고, 하네스 리뷰에서 전수 확인한다.

## Enforcement

- 쓰기 단계: `.claude/hooks/guard-content.mjs` (PreToolUse)
- 전체 점검: `oracle-compat-check` 스킬 (`--scan` 모드)

## Related

- [ADR-002](ADR-002_jdbc-driver-pinning.md): JDBC 드라이버 고정 (미검증)
- [ADR-003](ADR-003_pagination-interceptor.md): 페이징 공통화. Decision 2 의 패턴은 매퍼가 아니라 공통 인터셉터가 만든다.
